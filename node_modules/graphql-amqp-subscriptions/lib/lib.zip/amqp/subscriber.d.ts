import amqp from 'amqplib';
import Debug from 'debug';
import { PubSubAMQPConfig } from './interfaces';
export declare class AMQPSubscriber {
    private logger;
    private connection;
    private exchange;
    private queue;
    private channel;
    constructor(config: PubSubAMQPConfig, logger: Debug.IDebugger);
    subscribe(routingKey: string, action: (routingKey: string, message: any) => void, options?: amqp.Options.Consume): Promise<() => Promise<void>>;
    private getOrCreateChannel;
}
