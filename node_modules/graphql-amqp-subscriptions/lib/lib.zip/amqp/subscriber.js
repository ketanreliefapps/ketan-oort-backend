"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AMQPSubscriber = void 0;
const common_1 = require("./common");
class AMQPSubscriber {
    constructor(config, logger) {
        this.logger = logger;
        this.channel = null;
        this.connection = config.connection;
        this.exchange = {
            name: 'graphql_subscriptions',
            type: 'topic',
            options: {
                durable: false,
                autoDelete: false
            },
            ...config.exchange
        };
        this.queue = {
            options: {
                exclusive: true,
                durable: false,
                autoDelete: true
            },
            ...config.queue
        };
    }
    async subscribe(routingKey, action, options) {
        // Create and bind queue
        const channel = await this.getOrCreateChannel();
        await channel.assertExchange(this.exchange.name, this.exchange.type, this.exchange.options);
        const queue = await channel.assertQueue(this.queue.name || '', this.queue.options);
        await channel.bindQueue(queue.queue, this.exchange.name, routingKey);
        // Listen for messages
        const opts = await channel.consume(queue.queue, (msg) => {
            let parsedMessage = common_1.Logger.convertMessage(msg);
            this.logger('Message arrived from Queue "%s" (%j)', queue.queue, parsedMessage);
            action(routingKey, parsedMessage);
        }, { noAck: true, ...options });
        this.logger('Subscribed to Queue "%s" (%s)', queue.queue, opts.consumerTag);
        // Dispose callback
        return async () => {
            this.logger('Disposing Subscriber to Queue "%s" (%s)', queue.queue, opts.consumerTag);
            const ch = await this.getOrCreateChannel();
            await ch.cancel(opts.consumerTag);
            if (this.queue.unbindOnDispose) {
                await ch.unbindQueue(queue.queue, this.exchange.name, routingKey);
            }
            if (this.queue.deleteOnDispose) {
                await ch.deleteQueue(queue.queue);
            }
        };
    }
    async getOrCreateChannel() {
        if (!this.channel) {
            this.channel = await this.connection.createChannel();
            this.channel.on('error', (err) => { this.logger('Subscriber channel error: "%j"', err); });
        }
        return this.channel;
    }
}
exports.AMQPSubscriber = AMQPSubscriber;
