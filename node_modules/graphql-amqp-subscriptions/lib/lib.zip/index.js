"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AMQPPubSub = void 0;
/* istanbul ignore file */
var pubsub_1 = require("./pubsub");
Object.defineProperty(exports, "AMQPPubSub", { enumerable: true, get: function () { return pubsub_1.AMQPPubSub; } });
