import { PubSubEngine } from 'graphql-subscriptions';
import amqp from 'amqplib';
import { PubSubAMQPConfig } from './amqp/interfaces';
export declare class AMQPPubSub implements PubSubEngine {
    private publisher;
    private subscriber;
    private exchange;
    private subscriptionMap;
    private subsRefsMap;
    private unsubscribeMap;
    private currentSubscriptionId;
    constructor(config: PubSubAMQPConfig);
    publish(routingKey: string, payload: any, options?: amqp.Options.Publish): Promise<void>;
    subscribe(routingKey: string | 'fanout', onMessage: (message: any) => void, options?: amqp.Options.Consume): Promise<number>;
    unsubscribe(subId: number): Promise<void>;
    asyncIterator<T>(triggers: string | string[]): AsyncIterator<T>;
    private onMessage;
    private unsubscribeForKey;
}
